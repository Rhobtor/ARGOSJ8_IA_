#!/bin/bash
set -e

source /scripts/create_catkin_workspace.bash
source /scripts/install_ros_dependencies.bash
source /scripts/install_ouster_example_fork.bash
source /scripts/install_google_cartographer.bash
